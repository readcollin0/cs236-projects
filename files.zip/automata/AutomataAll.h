//
// Created by collin on 1/29/21.
//

#ifndef UNTITLED_AUTOMATAALL_H
#define UNTITLED_AUTOMATAALL_H

#include "Automaton.h"

#include "AutomatonComma.h"
#include "AutomatonPeriod.h"
#include "AutomatonQMark.h"
#include "AutomatonLeftParen.h"
#include "AutomatonRightParen.h"
#include "AutomatonColon.h"
#include "AutomatonColonDash.h"
#include "AutomatonMultiply.h"
#include "AutomatonAdd.h"
#include "AutomatonSchemes.h"
#include "AutomatonFacts.h"
#include "AutomatonRules.h"
#include "AutomatonQueries.h"
#include "AutomatonID.h"
#include "AutomatonString.h"
#include "AutomatonComment.h"
#include "AutomatonUndefined.h"

#endif //UNTITLED_AUTOMATAALL_H

//
// Created by collin on 1/29/21.
//

#ifndef UNTITLED_AUTOMATONSINGLECHAR_H
#define UNTITLED_AUTOMATONSINGLECHAR_H


#include "Automaton.h"

class AutomatonSingleChar : public Automaton {
private:
    const char matchChar;
public:
    AutomatonSingleChar(char matchChar, TokenType type) : Automaton(type), matchChar(matchChar) {}
    virtual ~AutomatonSingleChar() {}

    int Start(const std::string& input) {
        return s0(input, 0);
    }

private:
    int s0(const std::string& input, int pos) {
        if (checkChar(input, pos, matchChar) == 1)
            return pos + 1;
        return 0;
    }

};

#endif //UNTITLED_AUTOMATONSINGLECHAR_H
